import { Stack } from "expo-router";

import { AppProviders } from "@/core/providers/AppProviders";
import { LaunchStage } from "@/features/launch-intro";
import { statusBarLayout } from "@/features/status-bar";
import { ErrorBoundary, SuspenseFallback } from "@/core/monitoring/error-boundary";
import { HeaderArrivalProvider } from "@/ui/header-entrance/HeaderArrivalProvider";
import { headerEntranceLayout } from "@/ui/header-entrance/HeaderEntranceScope";
import { HALF_SHEET_OPTIONS } from "@/ui/SheetLayout";

/**
 * The tab bar's root screens. Header buttons animate in whenever the app
 * arrives at a screen — except moving between two of these. A tab with its own
 * stack is also named bare, as it reads for a moment before that stack opens.
 */
const TAB_ROOTS = [
  "(tabs)/home/index",
  "(tabs)/home",
  "(tabs)/plans/index",
  "(tabs)/plans",
  "(tabs)/fun/index",
  "(tabs)/fun",
  "(tabs)/progress/index",
  "(tabs)/progress",
  "(tabs)/settings/index",
  "(tabs)/settings",
];

export default function RootLayout() {
  return (
    <AppProviders>
      <HeaderArrivalProvider tabRoots={TAB_ROOTS}>
        {/* The cold-launch intro plays over the app, which stays hidden until it's revealed. */}
        <LaunchStage>
          {/* SundayBest draws its own status bar over the app (ADR 0032). */}
          <Stack
            screenOptions={{ headerShown: false }}
            screenLayout={headerEntranceLayout}
            layout={statusBarLayout}
          >
            {/*
             * Declared first so the launch route stays the initial route: explicitly listed
             * screens are registered ahead of auto-discovered ones.
             */}
            <Stack.Screen name="index" />
            {/*
             * Tabs are the app's settled root. There is no card transition from
             * the launch/onboarding route into them; on a cold return the native
             * splash fades onto an already-mounted Home screen instead of exposing
             * a root-stack slide underneath it. Tab-to-tab/navigation animations
             * inside this navigator are unaffected.
             */}
            <Stack.Screen name="(tabs)" options={{ animation: "none" }} />
            {/*
             * The Daily Study session — study, Day Complete, Quick Check — is one
             * native full-screen modal with its own stack. Screens inside it push
             * normally; leaving it dismisses the whole modal in one slide down,
             * back to whatever screen opened it.
             */}
            {/* Progress's weeks: zooms out of the week's dates (iOS 18's zoom, set by the link). */}
            <Stack.Screen name="weeks" />
            {/*
             * A week's plan, on top of Weeks — and the Settings pages its More
             * menu leads to, also at the root (`daily-reminder`, …) — so Back
             * returns to Weeks.
             */}
            <Stack.Screen name="plan/[planId]" />
            {/* Every reflection: zooms out of Your words' notebook (iOS 18's zoom, set by the link). */}
            <Stack.Screen name="reflections" options={{ gestureEnabled: false }} />
            {/* Every Quick Check: zooms out of the Quick Check page's button; only its close leaves. */}
            <Stack.Screen name="quick-checks" options={{ gestureEnabled: false }} />
            {/*
             * Plans' search: dissolves in over Plans, full screen, the keyboard
             * rising with it — with its own stack, so a plan found opens on top
             * of the results and Back returns to them.
             */}
            <Stack.Screen
              name="plan-search"
              options={{ presentation: "fullScreenModal", animation: "fade" }}
            />
            <Stack.Screen name="study" options={{ presentation: "fullScreenModal" }} />
            {/* RISE, the daily game: full screen over everything, closed by its X. */}
            <Stack.Screen
              name="rise"
              options={{ presentation: "fullScreenModal", gestureEnabled: false }}
            />
            {/*
             * New Plan — its two steps — is the same kind of full-screen modal:
             * it slides up over whatever opened it, and closes the moment the
             * plan is asked for.
             */}
            <Stack.Screen name="(plan-creation)" options={{ presentation: "fullScreenModal" }} />
            {/*
             * The plan being built, step by step: a native half-height sheet
             * over wherever the reader is, opened from the generation bar.
             */}
            <Stack.Screen name="generation" options={HALF_SHEET_OPTIONS} />
            {/*
             * A theology exam attempt — the questions, its results, and
             * Understand why — is another full-screen modal with its own stack,
             * over the exam's overview. The overview itself (`exams/[examId]/index`)
             * is an ordinary push above the tabs, so the tab bar steps aside.
             */}
            <Stack.Screen name="exam" options={{ presentation: "fullScreenModal" }} />
            {/*
             * An exam's topics and passages open over its overview as native
             * half-height sheets: iOS draws the grabber, and a drag down or a
             * tap on the dimmed overview above closes them.
             */}
            <Stack.Screen name="exams/[examId]/topics" options={HALF_SHEET_OPTIONS} />
            <Stack.Screen name="exams/[examId]/passages" options={HALF_SHEET_OPTIONS} />
          </Stack>
        </LaunchStage>
      </HeaderArrivalProvider>
    </AppProviders>
  );
}

// Expo Router recognises these named exports from a route file: ErrorBoundary
// replaces a crashed route's tree, SuspenseFallback covers a lazily-loaded
// one. See src/core/monitoring/error-boundary.tsx for the implementation and
// tests — this file stays a re-export per AGENTS.md's rule that src/app holds
// routes only.
export { ErrorBoundary, SuspenseFallback };
