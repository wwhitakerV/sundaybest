import { StyleSheet, View } from "react-native";
import { ALargeSmall, X } from "lucide-react-native";

import { HeaderIconButton } from "@/ui/atoms/HeaderIconButton";
import { ScreenHeader } from "@/ui/molecules/ScreenHeader";
import { StepProgress } from "@/ui/atoms/StepProgress";
import { getStepState } from "@/utils/steps/getStepState";
import { STUDY_STEPS, STUDY_STEP_COUNT } from "../logic/study-steps";
import { formatDayOfTotal } from "@/entities/plan";
import { space } from "@/theme";
import { SFProLabel } from "@/ui/typography/SFProLabel";

const TEXT_SIZE_ICON_SIZE = 20;
const STEP_LABEL_TOP_GAP = space[8];
// Mirrors `StepProgress`'s own segment gap so each label's flex-1
// container lines up under its corresponding progress segment — read
// only, `StepProgress` itself is untouched.
const STEP_PROGRESS_SEGMENT_GAP = space[4];

export type StudyHeaderProps = {
  day: number;
  totalDays: number;
  /** Dismisses the whole Daily Study modal. */
  onClose: () => void;
  onTextSize: () => void;
  /** 0-indexed position in Read/Scripture/Reflect/Pray. Omit to hide the tracker. */
  step?: number;
  /** Pages in each step (Reflect has one per question), and the page within `step`. */
  pages?: readonly number[];
  page?: number;
  testID: string;
};

/**
 * Shared by Read, Scripture, Reflect, and Pray — every screen in the daily
 * study flow has an identical close + "Day X of Y" + text-size header, plus
 * the 4-segment step tracker beneath it. Local to this slice rather than
 * `src/ui`: the day/step content is specific to the plan/day study
 * experience, though it's built from `src/ui`'s generic header/progress
 * primitives.
 */
export function StudyHeader({
  day,
  totalDays,
  onClose,
  onTextSize,
  step,
  pages,
  page,
  testID,
}: StudyHeaderProps) {
  return (
    <View style={styles.container}>
      <ScreenHeader
        testID={testID}
        title={formatDayOfTotal(day, totalDays)}
        left={
          <HeaderIconButton
            testID={`${testID}-close-button`}
            icon={X}
            accessibilityLabel="Close"
            onPress={onClose}
          />
        }
        right={
          <HeaderIconButton
            testID={`${testID}-text-size-button`}
            icon={ALargeSmall}
            size={TEXT_SIZE_ICON_SIZE}
            accessibilityLabel="Text size"
            onPress={onTextSize}
          />
        }
      />
      {step !== undefined && (
        <View>
          <StepProgress
            testID={`${testID}-progress`}
            steps={STUDY_STEP_COUNT}
            activeIndex={step}
            {...(pages && { pages })}
            {...(page !== undefined && { activePage: page })}
          />
          <View style={styles.labelRow}>
            {STUDY_STEPS.map(({ key, label, labelAlign }, index) => (
              <SFProLabel
                variant="stepLabel"
                tone={
                  getStepState(index, step) === "active" ? "stepLabelActive" : "stepLabelInactive"
                }
                style={[styles.label, { textAlign: labelAlign }]}
                key={key}
                testID={`${testID}-progress-label-${index}`}
                numberOfLines={1}
              >
                {label}
              </SFProLabel>
            ))}
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: space[16] },
  labelRow: {
    flexDirection: "row",
    gap: STEP_PROGRESS_SEGMENT_GAP,
    marginTop: STEP_LABEL_TOP_GAP,
  },
  label: { flex: 1 },
});
