import type { ReactNode } from "react";
import { StyleSheet, type StyleProp, type ViewStyle } from "react-native";
import Animated, { type AnimatedStyle } from "react-native-reanimated";

import { StudyDriftIn } from "./StudyDriftIn";
import { space } from "@/theme";

/** The animated style for a study page's second beat (`useStepTransition`'s `followStyle`). */
export type FollowStyle = StyleProp<AnimatedStyle<ViewStyle>>;

export type StudyFollowProps = {
  style?: FollowStyle;
  children: ReactNode;
};

/**
 * Everything on a Daily Study page below its kicker and title — the reading,
 * the verses, the question, the prayer — which comes in a beat after them.
 */
export function StudyFollow({ style, children }: StudyFollowProps) {
  return (
    <StudyDriftIn order={2}>
      <Animated.View style={[styles.follow, style]}>{children}</Animated.View>
    </StudyDriftIn>
  );
}

const styles = StyleSheet.create({
  follow: { gap: space[16] },
});
