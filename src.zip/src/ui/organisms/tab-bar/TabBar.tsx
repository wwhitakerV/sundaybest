import { useState, type ReactNode } from "react";
import { StyleSheet, type LayoutChangeEvent } from "react-native";
import Animated from "react-native-reanimated";
import { useNavigation, useNavigationContainerRef } from "expo-router";
import type { BottomTabBarProps } from "expo-router/tabs";

import { edgeFade, useTheme } from "@/theme";
import { BottomFade } from "@/ui/atoms/BottomFade";
import { getFloatingNavBarBottom, getFloatingNavBarTintHeight } from "../floatingNavBar";
import { GatheredTab } from "./GatheredTab";
import { OpenTabs } from "./OpenTabs";
import { TabBarBannerSlot } from "./TabBarBannerSlot";
import { TabBarAccessorySlot } from "./TabBarAccessorySlot";
import { TabBarFab } from "./TabBarFab";
import {
  CAPSULE_BORDER_WIDTH,
  CAPSULE_HEIGHT,
  CAPSULE_INSET_IN_ROW,
  CAPSULE_RADIUS,
  FAB_ROOM,
  FAB_SIZE,
  RAISE_GEOMETRY,
  RAISE_LIFT,
  SIDE_MARGIN,
} from "./tab-bar-geometry";
import {
  useShownTabBarAccessory,
  useTabBarFabHidden,
  type TabBarAccessory,
} from "./tab-bar-accessory";
import { useShownTabBarBanner } from "./tab-bar-banner";
import { useTabBarShown } from "./use-tab-bar-shown";
import { stackRootReset, tabsHolding } from "./stack-root-reset";
import { useTabBarMinimize } from "./use-tab-bar-minimize";
import { useTabBarBannerReveal, useTabBarRaise } from "./use-tab-bar-raise";
import { useTabBarReveal } from "./use-tab-bar-reveal";

export type TabBarProps = BottomTabBarProps & {
  /** Called on every tab and FAB press, before navigation. */
  onPress?: () => void;
  /** The floating button beside the tabs: what it's called, and what it does. */
  fab: { label: string; onPress: () => void };
  /** Routes over the tabs that are half sheets: the bar stays put beneath them, as iOS's does. */
  staysUnder?: readonly string[];
};

/**
 * The floating pill tab bar, plus a floating action button (FAB) beside it.
 * The app renders it through `Tabs`' `tabBar` prop — Expo Router's `Tabs`
 * takes a fully custom tab bar (`BottomTabBarProps`), which is what lets this
 * render as a floating capsule rather than the stock edge-to-edge bar.
 *
 * The FAB is not a fifth `Tabs.Screen`: what it's called and what it does
 * come from the caller (`fab`), so the bar knows no route of its own.
 *
 * The open tabs (`OpenTabs`) carry the active one's sliding pill; as it
 * slides, the newly active tab's icon coin-spins once and throws a small
 * burst of streaks upward (`AnimatedTabIcon`). The capsule itself carries
 * only its border, radius, and height.
 *
 * The whole bar reveals itself (`useTabBarReveal`) whenever the tabs are the
 * focused screen of the root stack — on first arriving, and each time a
 * modal or another screen pushed over the tabs is dismissed.
 * While something covers the tabs it sits back in its hidden position and
 * ignores touches, ready to animate up again.
 *
 * A screen can ask it to minimise beside a button of its own
 * (`useTabBarAccessory`): the tabs gather into a circle holding just the
 * active one, the button springs in to fill the space beside it, and the
 * FAB stays where it is. When the screen stops asking, it springs back open.
 * Tapping the gathered tabs opens them out while the screen's still asking:
 * the button rises above them to the bar's full width and the FAB shrinks to
 * the capsule's height (`useTabBarRaise`) — until the screen asks afresh.
 *
 * A banner can float above the tabs too (`useTabBarBanner`): it slides up
 * into the raised place at the bar's full width, and the FAB shrinks beside
 * the open tabs as it does for a raised button. A screen's raised button
 * takes that place first; the banner steps aside until it lowers again.
 *
 * `onPress` fires on every tab and FAB press, before navigation — this
 * component has no side-effect SDK access of its own (`ui` never imports
 * `core`), so haptic feedback is the caller's job.
 */
export function TabBar({ staysUnder = [], ...props }: TabBarProps) {
  const { state, descriptors, emitter, navigateToTab, insets, onPress, fab } = props;
  const theme = useTheme();
  // The `(tabs)` route's own navigation, in the stack that holds the tabs — and the
  // container, which takes an action aimed at the tabs themselves.
  const stack = useNavigation();
  const container = useNavigationContainerRef();
  const shown = useTabBarShown(staysUnder);
  const revealStyle = useTabBarReveal(shown);

  // Minimised beside a screen's button — or, once the gathered tabs are
  // tapped, open again with the button raised above them, until the screen
  // stops asking (and asks afresh). The last one asked for stays drawn while
  // it springs away, so it never empties mid-animation.
  const accessory = useShownTabBarAccessory();
  // A screen with no use for the FAB: it springs away, and the screen's button reaches the edge.
  const fabHidden = useTabBarFabHidden();
  const [raisedFor, setRaisedFor] = useState<TabBarAccessory | null>(null);
  const raised = accessory !== null && raisedFor === accessory;
  const minimized = accessory !== null && !raised;
  const [lastAccessory, setLastAccessory] = useState<TabBarAccessory | null>(accessory);
  if (accessory && accessory !== lastAccessory) setLastAccessory(accessory);
  const [rowWidth, setRowWidth] = useState(0);
  // A banner floats above the tabs unless a screen's button is raised there.
  const banner = useShownTabBarBanner();
  const bannerShown = banner !== null && banner !== undefined && !raised;
  const [lastBanner, setLastBanner] = useState<ReactNode>(banner);
  if (banner != null && banner !== lastBanner) setLastBanner(banner);
  const bannerStyle = useTabBarBannerReveal(bannerShown, RAISE_LIFT);
  const { slotStyle, fabStyle, tintStyle, fabGone } = useTabBarRaise(
    {
      buttonRaised: raised,
      fabShrunk: raised || (bannerShown && !minimized),
      tintRaised: raised || bannerShown,
      fabHidden,
    },
    // Far enough for the FAB to drop clean out of sight, below the screen's edge.
    { ...RAISE_GEOMETRY, fabDrop: FAB_SIZE + getFloatingNavBarBottom(insets.bottom) },
  );

  const { capsuleStyle, tabsStyle, gatheredStyle, buttonStyle } = useTabBarMinimize(
    minimized,
    accessory !== null,
    rowWidth > 0 ? rowWidth - FAB_ROOM : 0,
    CAPSULE_HEIGHT,
    // A screen with no use for the FAB: the tabs take its room as it goes.
    { room: FAB_ROOM, taken: fabGone },
  );
  const capsuleBottom = getFloatingNavBarBottom(insets.bottom);
  // Tall enough for the raised button; held down by the lift until it rises.
  const tintHeight = getFloatingNavBarTintHeight(capsuleBottom) + RAISE_LIFT;
  const activeRoute = state.routes[state.index];
  const activeOptions = activeRoute ? descriptors[activeRoute.key]?.options : undefined;
  function pressTab(routeKey: string, isActive: boolean) {
    onPress?.();
    const event = emitter.emit({ type: "tabPress", target: routeKey, canPreventDefault: true });
    if (event.defaultPrevented) return;
    if (!isActive) navigateToTab(routeKey);
    else {
      // Tapped again, a tab goes to its first page — even one a link left without it.
      const tabs = tabsHolding(stack.getState(), routeKey);
      const reset = tabs && stackRootReset(tabs, routeKey);
      if (reset) container.dispatch(reset);
    }
  }

  return (
    <Animated.View
      testID="tab-bar"
      onLayout={(event: LayoutChangeEvent) => setRowWidth(event.nativeEvent.layout.width)}
      style={[
        styles.wrapper,
        {
          // The capsule's bottom where every floating bar's goes; the FAB's a little lower.
          paddingBottom: capsuleBottom - CAPSULE_INSET_IN_ROW,
          pointerEvents: shown ? "box-none" : "none",
        },
        revealStyle,
      ]}
    >
      {/* Behind it all, edge to edge: hides what scrolls under the bar —
      solid below the capsule, fading out a little above it (or above the
      raised button). */}
      <Animated.View pointerEvents="none" style={[styles.tint, { height: tintHeight }, tintStyle]}>
        <BottomFade
          testID="tab-bar-tint"
          height={tintHeight}
          solidHeight={capsuleBottom + RAISE_LIFT}
          peak={edgeFade.peak}
        />
      </Animated.View>
      {/* Beneath the tabs, so it slides up out from behind them and back. */}
      {lastBanner != null && (
        <TabBarBannerSlot banner={lastBanner} shown={bannerShown} style={bannerStyle} />
      )}

      <Animated.View
        testID="tab-bar-capsule"
        style={[
          styles.capsule,
          { backgroundColor: theme.colors.background, borderColor: theme.colors.hairline },
          capsuleStyle,
        ]}
      >
        <OpenTabs
          state={state}
          descriptors={descriptors}
          minimized={minimized}
          style={tabsStyle}
          onPressTab={pressTab}
        />

        <GatheredTab
          minimized={minimized}
          routeName={activeRoute?.name}
          options={activeOptions}
          style={gatheredStyle}
          onPress={() => {
            onPress?.();
            setRaisedFor(accessory);
          }}
        />
      </Animated.View>

      {lastAccessory && (
        <TabBarAccessorySlot
          accessory={lastAccessory}
          shown={accessory !== null}
          style={[slotStyle, buttonStyle]}
        />
      )}

      {/* Always drawn, so it can spring away and back; out of reach while it's away. */}
      <TabBarFab
        label={fab.label}
        hidden={fabHidden}
        onPress={() => {
          onPress?.();
          fab.onPress();
        }}
        style={fabStyle}
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    left: SIDE_MARGIN,
    right: SIDE_MARGIN,
    bottom: 0,
    flexDirection: "row",
    paddingTop: RAISE_LIFT,
  },
  tint: { position: "absolute", left: -SIDE_MARGIN, right: -SIDE_MARGIN, bottom: 0 },
  // Leaves the FAB its room, and is centred on it by its margins — so the row
  // is the FAB's height without the FAB being in it.
  capsule: {
    flex: 1,
    marginRight: FAB_ROOM,
    marginVertical: CAPSULE_INSET_IN_ROW,
    height: CAPSULE_HEIGHT,
    borderRadius: CAPSULE_RADIUS,
    borderWidth: CAPSULE_BORDER_WIDTH,
  },
});
