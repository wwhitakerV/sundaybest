import { space } from "@/theme";
import { getFloatingNavBarBottom, getFloatingNavBarTintHeight } from "./floatingNavBar";
import { PAGE_TOP } from "./Screen";

/**
 * How far a page's edge fades past what's solid — below a header, above the
 * dock — the same 16pt the tab bar's tint rises above its pill.
 */
export const EDGE_FADE = space[16];

/**
 * How tall a gradual header fade is: thicker than the dock's, kept inside
 * the header's own block so it ends exactly at the header's bottom edge.
 */
export const GRADUAL_FADE = space[32];

/**
 * A gradual fade's ramp, solid to clear down its height: eased, so it melts
 * away rather than reading as a band. `at` runs 0–1 down the ramp.
 */
export const GRADUAL_RAMP = [
  { at: 0, opacity: 1 },
  { at: 0.25, opacity: 0.88 },
  { at: 0.5, opacity: 0.6 },
  { at: 0.75, opacity: 0.25 },
  { at: 1, opacity: 0 },
] as const;

/** A fade's opacities down its ramp; `at` runs 0–1 from where it stops being solid. */
type FadeRamp = readonly { at: number; opacity: number }[];

/** A soft fade starts this far above the header's last row… */
const SOFT_ABOVE = space[10];
/** …is this opaque at the header's bottom edge (80% clear)… */
const SOFT_EDGE_OPACITY = 0.2;
/** …and is fully clear this far past it. */
const SOFT_PAST = space[10];

/**
 * How a header meets what scrolls under it: `"edge"`, a short fade just below
 * it; `"gradual"`, a thicker eased fade inside its own block; `soft`, a fade
 * from just above the header's last row (`reach` tall — Plans' filters) to a
 * little past its bottom edge, mostly clear by that edge.
 */
export type HeaderFade = "edge" | "gradual" | { kind: "soft"; reach: number };

/** What sits at a frame's foot: the dock, a verdict panel in its place, or nothing. */
export type FrameFoot = { kind: "none" } | { kind: "dock" } | { kind: "panel"; height: number };

/**
 * One edge of a page: how much of it is solid, how tall its fade is in all
 * (solid included, measured in from the screen's edge), and how far in its
 * content starts so it's clear of both.
 */
export type FrameEdge = { solid: number; height: number; clearance: number; ramp?: FadeRamp };

/**
 * A scrolling page's two edges. The scroll runs the phone's full height;
 * these say what covers each end of it, so what scrolls under a header or the
 * dock dissolves into the page instead of stopping at a line.
 *
 * `headerHeight` is the floating header's whole block, status bar included
 * (0 when there's none, or before it's measured) — with a gradual fade, its
 * fade's room too.
 */
export function getFrameEdges({
  insetTop,
  insetBottom,
  headerHeight,
  headerFade = "edge",
  foot,
}: {
  insetTop: number;
  insetBottom: number;
  headerHeight: number;
  headerFade?: HeaderFade;
  foot: FrameFoot;
}): { top: FrameEdge; bottom: FrameEdge } {
  return {
    top: topEdge(insetTop, headerHeight, headerFade),
    bottom: bottomEdge(insetBottom, foot),
  };
}

function topEdge(insetTop: number, headerHeight: number, headerFade: HeaderFade): FrameEdge {
  if (headerHeight <= 0) {
    return { solid: insetTop, height: insetTop + EDGE_FADE, clearance: insetTop + PAGE_TOP };
  }
  if (headerFade === "gradual") {
    // The ramp is the foot of the header's own block: it ends at its bottom edge.
    return {
      solid: headerHeight - GRADUAL_FADE,
      height: headerHeight,
      clearance: headerHeight,
      ramp: GRADUAL_RAMP,
    };
  }
  if (typeof headerFade === "object") return softTopEdge(headerHeight, headerFade.reach);
  const height = headerHeight + EDGE_FADE;
  return { solid: headerHeight, height, clearance: height };
}

/**
 * A header's own backdrop, drawn inside the header's block so it's always
 * the header's size — no measuring: solid down the block, then `fade` tall
 * to clear, ending `past` below the block's bottom edge. The same fades
 * `getFrameEdges` describes from the outside, with the measured height.
 */
export function getHeaderBackdrop(headerFade: HeaderFade): {
  past: number;
  fade: number;
  ramp: FadeRamp;
} {
  if (headerFade === "gradual") return { past: 0, fade: GRADUAL_FADE, ramp: GRADUAL_RAMP };
  if (typeof headerFade === "object") {
    const { ramp } = softTopEdge(0, headerFade.reach);
    return {
      past: SOFT_PAST,
      fade: headerFade.reach + SOFT_ABOVE + SOFT_PAST,
      ramp: ramp ?? LINEAR_RAMP,
    };
  }
  return { past: EDGE_FADE, fade: EDGE_FADE, ramp: LINEAR_RAMP };
}

const LINEAR_RAMP = [
  { at: 0, opacity: 1 },
  { at: 1, opacity: 0 },
] as const;

function bottomEdge(insetBottom: number, foot: FrameFoot): FrameEdge {
  if (foot.kind === "dock") {
    // Exactly the tab bar's tint, so the two look like one container.
    const capsuleBottom = getFloatingNavBarBottom(insetBottom);
    const height = getFloatingNavBarTintHeight(capsuleBottom);
    return { solid: capsuleBottom, height, clearance: height };
  }
  const solid = foot.kind === "panel" ? foot.height : insetBottom;
  return { solid, height: solid + EDGE_FADE, clearance: solid + EDGE_FADE };
}

function softTopEdge(headerHeight: number, reach: number): FrameEdge {
  const solid = headerHeight - reach - SOFT_ABOVE;
  const height = headerHeight + SOFT_PAST;
  // Where the header's bottom edge falls on the ramp.
  const edge = (reach + SOFT_ABOVE) / (reach + SOFT_ABOVE + SOFT_PAST);
  return {
    solid,
    height,
    clearance: height,
    ramp: [
      { at: 0, opacity: 1 },
      { at: edge / 2, opacity: 0.7 },
      { at: edge, opacity: SOFT_EDGE_OPACITY },
      { at: 1, opacity: 0 },
    ],
  };
}
