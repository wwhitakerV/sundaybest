import { createContext, useContext, type ReactNode } from "react";
import { Text, type StyleProp, type TextProps, type TextStyle } from "react-native";

import { useTheme } from "@/theme";
import { scaleTypeStyle, toneColor, type Tone } from "./tone";
import { useTextOffset } from "./TextSizeScope";
import { useTextScale } from "./use-text-scale";

/** What a caller may style: where the text sits, never its face, size, weight, leading, tracking or colour. */
export type LayoutTextStyle = Omit<
  TextStyle,
  "fontFamily" | "fontSize" | "fontWeight" | "fontStyle" | "lineHeight" | "letterSpacing" | "color"
> & {
  // Named as never, not only left out, so a stylesheet entry that sets one is a type error.
  fontFamily?: never;
  fontSize?: never;
  fontWeight?: never;
  fontStyle?: never;
  lineHeight?: never;
  letterSpacing?: never;
  color?: never;
};

/** The cut a line is drawn in, for a `Span` inside it to take that cut's italic. */
const LineFace = createContext<string | undefined>(undefined);

/** The cut of the line this text sits in. */
export function useLineFace(): string | undefined {
  return useContext(LineFace);
}

/** Props every typography component takes. */
export type TypographyProps = Omit<TextProps, "style"> & {
  tone?: Tone;
  style?: StyleProp<LayoutTextStyle>;
  children?: ReactNode;
};

/**
 * The one place text is drawn: a type style from the theme, a semantic
 * tone, and a layout-only style on top. Private to `src/ui/typography`;
 * everything else uses the named components built on it.
 */
export function ThemedText({
  type,
  tone = "text",
  fixed = false,
  style,
  ...props
}: TypographyProps & {
  type: TextStyle;
  /** Drawn at its designed size whatever the reader's text size or iOS's (the status bar). */
  fixed?: boolean;
}) {
  const theme = useTheme();
  const scale = useTextScale();
  const offset = useTextOffset();

  return (
    <LineFace.Provider value={typeof type.fontFamily === "string" ? type.fontFamily : undefined}>
      <Text
        {...props}
        {...(fixed && { allowFontScaling: false })}
        style={[
          fixed ? type : scaleTypeStyle(type, scale, offset),
          { color: toneColor(theme.colors, tone) },
          style,
        ]}
      />
    </LineFace.Provider>
  );
}
