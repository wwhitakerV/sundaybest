import { StyleSheet, View } from "react-native";

import { space, type Theme, useTheme } from "@/theme";
import { getSegmentFill } from "@/utils/steps/getSegmentFill";
import { getStepState, type StepState } from "@/utils/steps/getStepState";

const SEGMENT_HEIGHT = 3;
const GAP = space[4];
/** A page mark: a ring the line's height, white in the middle. */
const DOT_SIZE = SEGMENT_HEIGHT;
const DOT_RING = 0.25;

/** The ink of the colour the line sits on; undefined on the app's own page. */
type LineInk = "light" | "dark";

function segmentColor(state: StepState, theme: Theme, ink: LineInk | undefined): string {
  switch (state) {
    case "completed":
      return ink === "light" ? theme.colors.inkOnDark : theme.colors.text;
    case "active":
      return theme.colors.accent;
    case "upcoming":
      if (ink === "light") return theme.colors.inkOnDarkFaint;
      return ink === "dark" ? theme.colors.inkOnLightFaint : theme.colors.divider;
  }
}

export type StepProgressProps = {
  /** Total number of steps — 4 for the daily study flow, 3 for Quick Check. */
  steps: number;
  /** 0-indexed. Segments before this are complete; this one is active; after are upcoming. */
  activeIndex: number;
  /** Pages in each step, in order, when a step has more than one. One each if omitted. */
  pages?: readonly number[];
  /** 0-indexed page within the active step. */
  activePage?: number;
  /**
   * Set on a colour of the content's own: `light` ink on a dark colour
   * (done steps white), `dark` ink on a light one. Omit on the app's page.
   */
  ink?: "light" | "dark";
  testID?: string;
};

/**
 * The horizontal line tracker under a study or Quick Check header: solid
 * dark for a completed step, accent-coloured for the current one, light
 * grey for what's ahead. Shared by Read/Scripture/Reflect/Pray (4 steps)
 * and Quick Check (3 steps) rather than duplicated per screen.
 *
 * A step with several pages (Reflect's questions) is marked off by a dot
 * where each later page begins — a ring in the segment's colour, white in
 * the middle — and the current one fills in accent only as far as the page
 * the user is on.
 */
export function StepProgress({
  steps,
  activeIndex,
  pages,
  activePage = 0,
  ink,
  testID,
}: StepProgressProps) {
  const theme = useTheme();

  return (
    <View testID={testID} style={styles.row}>
      {Array.from({ length: steps }, (_, index) => {
        const state = getStepState(index, activeIndex);
        const segmentID = testID && `${testID}-segment-${index}`;
        const pageCount = pages?.at(index) ?? 1;

        if (pageCount <= 1) {
          return (
            <View
              key={index}
              testID={segmentID}
              style={[styles.segment, { backgroundColor: segmentColor(state, theme, ink) }]}
            />
          );
        }

        const { fill, dots } = getSegmentFill(state, pageCount, activePage);
        const fillColor = segmentColor(state === "completed" ? "completed" : "active", theme, ink);
        const trackColor = state === "completed" ? fillColor : segmentColor("upcoming", theme, ink);

        return (
          <View
            key={index}
            testID={segmentID}
            style={[styles.segment, { backgroundColor: trackColor }]}
          >
            {state === "active" && (
              <View
                testID={segmentID && `${segmentID}-fill`}
                style={[styles.fill, { width: `${fill * 100}%`, backgroundColor: fillColor }]}
              />
            )}
            {dots.map((at, dotIndex) => (
              <View
                key={at}
                testID={segmentID && `${segmentID}-dot-${dotIndex + 1}`}
                style={[
                  styles.dot,
                  {
                    left: `${at * 100}%`,
                    borderColor: state === "upcoming" ? trackColor : fillColor,
                    backgroundColor: theme.colors.background,
                  },
                ]}
              />
            ))}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", gap: GAP },
  segment: { flex: 1, height: SEGMENT_HEIGHT, borderRadius: SEGMENT_HEIGHT / 2 },
  fill: { height: SEGMENT_HEIGHT, borderRadius: SEGMENT_HEIGHT / 2 },
  dot: {
    position: "absolute",
    top: (SEGMENT_HEIGHT - DOT_SIZE) / 2,
    width: DOT_SIZE,
    height: DOT_SIZE,
    borderRadius: DOT_SIZE / 2,
    borderWidth: DOT_RING,
    marginLeft: -DOT_SIZE / 2,
  },
});
