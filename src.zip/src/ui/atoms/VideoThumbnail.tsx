import { StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";
import { Image } from "expo-image";
import { Play } from "lucide-react-native";

import { radius, space, useTheme } from "@/theme";
import { MonoBody } from "@/ui/typography/MonoBody";

export type VideoThumbnailProps = {
  /** The video's still, if it has one; a plain frame with a play mark stands in until it loads. */
  uri: string | null;
  /** Shown in the corner, e.g. `42:18`. */
  duration?: string;
  testID?: string;
  style?: StyleProp<ViewStyle>;
};

/** A video's thumbnail, 16:9: its still over a quiet frame, a play mark, and its length. */
export function VideoThumbnail({ uri, duration, testID, style }: VideoThumbnailProps) {
  const theme = useTheme();

  return (
    <View
      testID={testID}
      style={[styles.frame, { backgroundColor: theme.colors.segmentBackground }, style]}
    >
      <Play size={32} color={theme.colors.textMuted} strokeWidth={theme.icon.strokeWidth} />
      {uri && (
        // expo-image: decoded off the main thread and kept in memory and on
        // disk, so a thumbnail seen once — or warmed by `prefetchImages` —
        // draws at once everywhere it appears, with no fade to wait through.
        <Image
          source={{ uri }}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          cachePolicy="memory-disk"
          recyclingKey={uri}
        />
      )}
      {duration && (
        <View
          style={[
            styles.duration,
            { backgroundColor: theme.colors.mediaScrim, borderRadius: radius.pill },
          ]}
        >
          <MonoBody variant="counter" tone="onMediaScrim">
            {duration}
          </MonoBody>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    aspectRatio: 16 / 9,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  duration: {
    position: "absolute",
    right: 12,
    bottom: 12,
    paddingHorizontal: space[12],
    paddingVertical: space[4],
  },
});
