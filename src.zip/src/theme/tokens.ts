/** Design tokens. Every colour has a light and a dark value. */
import type { ReadingPaper } from "@/types/domain";

import { fonts } from "./fonts";
import { LAUNCH_PAGE } from "./launch-colors";

const palette = {
  white: "#FFFFFF",
  // Reading papers (READING_PAPERS): three warm off-whites, and a dark one
  // softer than night's.
  paperIvory: "#FBF8F1",
  paperCream: "#F5EEDF",
  paperSepia: "#EBDFC6",
  paperDusk: "#2A2B30",
  ink900: "#10131A",
  ink600: "#4A5160",
  ink300: "#9AA1B1",
  paper: "#F6F7FA",
  /** A step darker than paper, with only a hint of its blue: what's picked (the active tab). */
  paperShade: "#ECEDF0",
  slate900: "#0B0D12",
  slate700: "#171A21",
  accent: "#D62626",
  // RISE's balloons: a saved one's green — set darker than the red, so the
  // two part by lightness too, for eyes that don't tell red from green — and
  // a burst one's torn latex, matte and a step darker than the red.
  balloonGreen: "#1A7044",
  balloonScrap: "#9E1C1C",
  lightIcon: "#d2d2d0",
  // A quiet grey that still reads as a line on white — lighter than
  // `lightIcon`, firmer than `mist`. Not from the brand
  // spec: set for Plan Detail's step sequence.
  greyLight: "#E4E4E7",
  // Brand palette. Fixed values, not theme-dependent — same as `accent`
  // above, these read the same in light and dark. More colours land here as
  // they're specified; this is not yet the full set.
  black: "#08090A",
  red: "#D62626",
  green: "#00A378",
  darkgrey: "#55555D",
  grey: "#8A8A92",
  // Supporting copy on a dark page: a step softer than white, well clear of `grey`.
  silver: "#B4B4BB",
  // A waiting control's words: grey enough to read as not yet, dark enough
  // to read on its grey fill.
  waitingInk: "#71717A",
  // Navigation-chrome ink. Close to but distinct from `black` above — the
  // header/title/icon spec calls for this exact value, not the brand black.
  ink: "#111113",
  // Lines on the page, cool like `paper` and never warm: a row's hairline,
  // a container's edge, and a sheet's grabber — each a step darker than the
  // last. Each has a dark twin, the same steps up from a dark surface.
  mist: "#EFF0F3",
  cardEdge: "#E7E8EB",
  grabber: "#C5C6CA",
  mistOnDark: "#24272E",
  cardEdgeOnDark: "#33363C",
  grabberOnDark: "#52555E",
  // Overlay tints used by header icon buttons, the tab bar, and segmented
  // controls in the light theme — black-on-white, per spec.
  hairline: "rgba(0, 0, 0, 0.06)",
  overlaySubtle: "rgba(0, 0, 0, 0.03)",
  overlayLight: "rgba(0, 0, 0, 0.08)",
  overlayMedium: "rgba(0, 0, 0, 0.09)",
  overlayStrong: "rgba(0, 0, 0, 0.10)",
  // The same overlays, inverted for a dark background. The spec only gives
  // light-mode values; these keep the same relative opacities on white
  // instead of black so the chrome remains visible in dark mode.
  hairlineOnDark: "rgba(255, 255, 255, 0.12)",
  overlaySubtleOnDark: "rgba(255, 255, 255, 0.06)",
  overlayMediumOnDark: "rgba(255, 255, 255, 0.16)",
  overlayStrongOnDark: "rgba(255, 255, 255, 0.18)",
  // Darkening laid over video thumbnails, under their play button and time.
  scrim: "rgba(0, 0, 0, 0.45)",
  /** A light dim behind a popover that wants the page to step back a little. */
  dimLight: "rgba(0, 0, 0, 0.12)",
  dimOnDark: "rgba(0, 0, 0, 0.4)",
  // Quick Check's verdicts: a deep green for right and a deep amber for a
  // miss — "not yet", never the brand red, which means only "this one" and
  // "now" — each with a soft tint to fill and a lighter line to edge it. The
  // amber is dark enough to read as text on white; on a dark page, lighter.
  correctInk: "#2E8A5E",
  correctMist: "#EEF6F1",
  correctLine: "#A9D3BC",
  amber: "#B45309",
  amberOnDark: "#E5A04F",
  incorrectMist: "#FCF3E8",
  incorrectLine: "#EBC79A",
  correctMistOnDark: "#16261E",
  correctLineOnDark: "#2F5A44",
  incorrectMistOnDark: "#2A2014",
  // An exam subject's folio, a bound book: a near-black cloth cover with
  // warm paper-white ink on it, and the same paper for a cover not in view.
  folioCloth: "#171717",
  folioClothEdge: "#292929",
  folioPaper: "#F4F1EB",
  folioPaperMuted: "#C6C2BB",
  folioPaperFaint: "#BBB7B1",
  folioPaperRule: "rgba(244, 241, 235, 0.65)",
  folioPaperRuleFaint: "rgba(244, 241, 235, 0.38)",
  folioPaperEdgeStrong: "rgba(244, 241, 235, 0.8)",
  folioPressed: "rgba(255, 255, 255, 0.07)",
  folioPaperEdge: "#E4DFD6",
  // A choice that's picked, on a card of its own (an exam's way in): the
  // accent, softened to a wash, an edge, and a badge between the two.
  selectionMist: "#FEF5F5",
  selectionEdge: "#F4CFCF",
  selectionBlush: "#FBE4E4",
  selectionMistOnDark: "#241415",
  selectionEdgeOnDark: "#5A2626",
  selectionBlushOnDark: "#3A1C1D",
  incorrectLineOnDark: "#6B4D24",
  // Type and marks on a colour of the content's own (a featured sermon's):
  // white on a dark one, black on a light one, each full, muted, and faint.
  whiteMuted: "rgba(255, 255, 255, 0.72)",
  whiteFaint: "rgba(255, 255, 255, 0.28)",
  blackMuted: "rgba(8, 9, 10, 0.6)",
  blackFaint: "rgba(8, 9, 10, 0.18)",
  // A floating button's fill over content's own colour: dark on a dark
  // colour, light on a light one — so it sits in, not on.
  blackVeil: "rgba(8, 9, 10, 0.5)",
  whiteVeil: "rgba(255, 255, 255, 0.85)",
  // A soft halo behind words set over a picture, keeping them readable.
  blackHalo: "rgba(0, 0, 0, 0.35)",
  whiteHalo: "rgba(255, 255, 255, 0.5)",
  // A see-through rim around a floating card: the page, frosted.
  frost: "rgba(255, 255, 255, 0.6)",
  frostOnDark: "rgba(11, 13, 18, 0.6)",
  // The Daily Study step labels (Read/Scripture/Reflect/Pray) beneath the
  // progress lines. Pure black per spec — distinct from `black` above,
  // which is the app's near-black brand value, not literal #000.
  pureBlack: "#000000",
  stepLabelInactive: "#A1A1AA",
  // Pastels matched to the backdrops baked into Fun's illustrations, so each
  // one dissolves into the card it's set on: a hazy dawn (light, mid, deep),
  // rose, blush, butter, lilac, and sky.
  dawnLight: "#F8F5F1",
  dawn: "#F5EBDD",
  dawnDeep: "#F1D7A9",
  rose: "#FBDDE5",
  blush: "#FDF1F6",
  butter: "#FDF6E5",
  lilac: "#F5ECFA",
  sky: "#EFF6FD",
} as const;

/**
 * Widened to `string` on purpose: annotating both palettes with the same shape
 * is what makes them interchangeable. Typing `darkColors` as
 * `typeof lightColors` instead would infer the *literal* light hex values and
 * reject every dark one.
 */
type ColorTokens = {
  background: string;
  /** The launch intro's page: the red its movie starts on, and the native launch screen (launch-colors.ts). */
  launchPage: string;
  surface: string;
  text: string;
  lightIcon: string;
  /** Secondary text: the quieter half of a heading, supporting copy, footnotes. */
  textMuted: string;
  /** Inactive items in a strip or set. Darker than `textMuted`. */
  textInactive: string;
  /**
   * Explanatory copy meant to be read — a page's note, a choice's detail:
   * quieter than `text`, clearly darker than `textMuted`, at regular weight.
   */
  textSupporting: string;
  border: string;
  /** A heavier edge, for a control that should stand out from the chrome around it. */
  borderStrong: string;
  /** Hairline rules between list rows. Darker than `surface`, lighter than `containerBorder`. */
  divider: string;
  /**
   * The edge of a card or grouped container — Settings' groups, `Card`, the
   * soft buttons. One token, so every container's edge is the same line.
   */
  containerBorder: string;
  /** An edge that holds against the soft `surface` grey, where `containerBorder` fades into it: a pill on Text size's preview. */
  edgeOnSurface: string;
  /** Behind a popover that dims the page a little while it's open (Progress's weeks). */
  popoverDim: string;
  /** A sheet's drag indicator: quiet, but plainly there. */
  grabber: string;
  /** The unfilled track of a ring or a scale, and a ring not yet earned. */
  progressTrack: string;
  /** A skeleton's blocks, standing in for content while it loads. */
  skeleton: string;
  accent: string;
  /**
   * Text and icons set on `accent` — the step you're on, on Plan Detail's day.
   */
  onAccent: string;
  /**
   * The quiet line a sequence runs along — joining the steps of Plan
   * Detail's day — and the ring of a step still to come on it.
   */
  sequenceLine: string;
  /** Filled primary controls — the button fill, not the page background. */
  controlPrimary: string;
  /** Text and icons sitting on `controlPrimary`. */
  onControlPrimary: string;
  /** Secondary text on `controlPrimary` — a build's step under its title. */
  onControlPrimaryMuted: string;
  /** Lines and tracks on `controlPrimary` — the generation bar's divider and progress track. */
  onControlPrimaryFaint: string;
  /** Something finished and ready — the generation bar once a plan is built. The brand green. */
  success: string;
  /** Text and icons on `success`; the green is light, so its ink is dark. */
  onSuccess: string;
  /** Secondary text on `success` — the ready plan's title under "Your plan is ready". */
  onSuccessMuted: string;
  /** Lines on `success` — the generation bar's divider. */
  onSuccessFaint: string;
  /** Bright ink on `success`, for a whole green surface: the ready sheet's words, mark, and button. */
  onSuccessBright: string;
  /** Lines on `success` beside that bright ink: the ready bar's divider. */
  onSuccessBrightFaint: string;
  /** The active item in a selector or strip. */
  selected: string;
  /** A toggle's knob while it's off, on its `divider` track. (On, it takes `onAccent`.) */
  toggleThumbOff: string;
  /** Header/tab-bar icon colour, and the centered nav-title's active state. */
  chromeIcon: string;
  /** The status bar's time and battery on the page. */
  statusInk: string;
  /** The status bar's time and battery over a dark hero or paper (`StatusBarTone light`). */
  statusInkOnDark: string;
  /** The centered header title's own colour — quieter than `chromeIcon`. */
  chromeTitle: string;
  /** The right-aligned step counter in a header ("1 of 2"). */
  chromeStepCounter: string;
  /** The 1px border on header icon buttons and the floating tab bar. */
  hairline: string;
  /** A segmented control's unselected track. */
  segmentBackground: string;
  /**
   * A way on that's waiting (a day not open yet): an opaque grey fill — plainly
   * there, plainly not ready, never mistaken for the white or black of one that is.
   */
  waitingFill: string;
  /** The words and icon on `waitingFill`. */
  waitingInk: string;
  /** A segmented control's selected segment. */
  segmentActiveBackground: string;
  /** An active tab's background pill inside the floating tab bar. */
  tabActiveBackground: string;
  /** The Daily Study step label (Read/Scripture/Reflect/Pray) for the current step. */
  stepLabelActive: string;
  /** A Daily Study step label for a completed or upcoming step — same grey either way. */
  stepLabelInactive: string;
  /** The bezel and camera island of a drawn phone (the Welcome screen's mock screens). */
  deviceFrame: string;
  /** Drop-shadow colour for raised surfaces; paired with `theme.elevation`. */
  shadow: string;
  /** Darkening over a video thumbnail, behind its play button and running time. */
  mediaScrim: string;
  /** Text and icons on `mediaScrim`. */
  onMediaScrim: string;
  /**
   * The see-through rim of a card floating over the page — the Welcome
   * story's lifted pieces. What's behind it shows through, faintly.
   */
  frostedRim: string;
  /** RISE: a balloon saved into the atmosphere, its answer right. */
  balloonSaved: string;
  /** RISE: a burst balloon's torn latex, left where it fell. */
  balloonScrap: string;
  /** A right answer: its check, and the words saying so. */
  correct: string;
  /** Behind a right answer, and its verdict panel. */
  correctSurface: string;
  /** The edge of a right answer. */
  correctBorder: string;
  /** A wrong answer — a deep amber, "not yet", never the brand red: its mark, and the words saying so. */
  incorrect: string;
  /** Behind a wrong answer, and its verdict panel. */
  incorrectSurface: string;
  /** The edge of a wrong answer. */
  incorrectBorder: string;
  /**
   * An exam subject's folio — a bound book, the same in either theme: its
   * cloth cover and edge, and the paper-white ink on it (full, muted,
   * faint), its rules (the heading's, and the fainter one between exams),
   * an exam's arrow box, and the lift under a pressed row. A cover not in
   * view is the paper itself, edged, with cloth-dark ink.
   */
  folioCloth: string;
  folioClothEdge: string;
  /** The black spine binding a cover's left edge, up to its accent rule. */
  folioSpine: string;
  folioInk: string;
  folioInkMuted: string;
  folioInkFaint: string;
  folioRule: string;
  folioRuleFaint: string;
  folioArrowEdge: string;
  folioPressed: string;
  folioPaper: string;
  folioPaperEdge: string;
  /** Behind a choice that's picked, on a card of its own (an exam's way in). */
  selectionSurface: string;
  /** Its edge — the accent itself runs down its leading side. */
  selectionBorder: string;
  /** A round badge on it, a step deeper than its surface. */
  selectionBadge: string;
  /**
   * A wrong answer in a theology exam: ink, never red — a wrong answer there
   * is a teachable moment, and red is kept for what's selected. Always paired
   * with a ✕ and the word "Incorrect", never colour alone.
   */
  feedbackIncorrect: string;
  /**
   * Type and marks on a colour of the content's own — a featured sermon's —
   * whatever the app's theme: `inkOnDark*` on a dark one, `inkOnLight*` on a
   * light one (`prefersLightInk` picks). Full, muted, and faint.
   */
  inkOnDark: string;
  inkOnDarkMuted: string;
  inkOnDarkFaint: string;
  inkOnLight: string;
  inkOnLightMuted: string;
  inkOnLightFaint: string;
  /** Behind featured content whose own colour isn't known yet. */
  featureBackdrop: string;
  /** A floating button's fill over a dark colour of the content's own (its icon `inkOnDark`). */
  overlayButtonDark: string;
  /** …and over a light one (its icon `inkOnLight`). */
  overlayButtonLight: string;
  /** The soft shadow behind light words set over a picture… */
  inkHaloOnDark: string;
  /** …and behind dark ones. */
  inkHaloOnLight: string;
  /**
   * Behind an illustration that carries a light backdrop of its own (Fun's
   * games): a pastel matched to it, so the art dissolves into its card. The
   * same in either theme, as the art's backdrop is; words and marks on one
   * are `inkOnLight*`. Dawn is a gradient — light, mid, deep. Rose is blush
   * with more red.
   */
  illustrationDawnLight: string;
  illustrationDawn: string;
  illustrationDawnDeep: string;
  illustrationRose: string;
  illustrationBlush: string;
  illustrationButter: string;
  illustrationLilac: string;
  illustrationSky: string;
};

const lightColors: ColorTokens = {
  background: palette.white,
  launchPage: LAUNCH_PAGE,
  surface: palette.paper,
  text: palette.black,
  textMuted: palette.grey,
  textInactive: palette.darkgrey,
  textSupporting: palette.darkgrey,
  border: palette.ink300,
  borderStrong: palette.darkgrey,
  divider: palette.mist,
  containerBorder: palette.cardEdge,
  edgeOnSurface: palette.grabber,
  popoverDim: palette.dimLight,
  grabber: palette.grabber,
  progressTrack: palette.greyLight,
  skeleton: palette.cardEdge,
  accent: palette.accent,
  onAccent: palette.white,
  sequenceLine: palette.greyLight,
  controlPrimary: palette.black,
  onControlPrimary: palette.white,
  onControlPrimaryMuted: palette.whiteMuted,
  onControlPrimaryFaint: palette.whiteFaint,
  success: palette.green,
  onSuccess: palette.black,
  onSuccessMuted: palette.blackMuted,
  onSuccessFaint: palette.blackFaint,
  onSuccessBright: palette.white,
  onSuccessBrightFaint: palette.whiteFaint,
  lightIcon: palette.lightIcon,
  selected: palette.green,
  toggleThumbOff: palette.white,
  chromeIcon: palette.ink,
  statusInk: palette.black,
  statusInkOnDark: palette.white,
  chromeTitle: palette.darkgrey,
  chromeStepCounter: palette.grey,
  hairline: palette.hairline,
  segmentBackground: palette.overlaySubtle,
  waitingFill: palette.greyLight,
  waitingInk: palette.waitingInk,
  segmentActiveBackground: palette.overlayMedium,
  // A step darker than the app's soft fill, with a hint of its blue — not a flat grey of its own.
  tabActiveBackground: palette.paperShade,
  stepLabelActive: palette.pureBlack,
  stepLabelInactive: palette.stepLabelInactive,
  deviceFrame: palette.ink,
  shadow: palette.pureBlack,
  mediaScrim: palette.scrim,
  onMediaScrim: palette.white,
  frostedRim: palette.frost,
  balloonSaved: palette.balloonGreen,
  balloonScrap: palette.balloonScrap,
  correct: palette.correctInk,
  correctSurface: palette.correctMist,
  correctBorder: palette.correctLine,
  incorrect: palette.amber,
  incorrectSurface: palette.incorrectMist,
  folioCloth: palette.folioCloth,
  folioClothEdge: palette.folioClothEdge,
  folioSpine: palette.pureBlack,
  folioInk: palette.folioPaper,
  folioInkMuted: palette.folioPaperMuted,
  folioInkFaint: palette.folioPaperFaint,
  folioRule: palette.folioPaperRule,
  folioRuleFaint: palette.folioPaperRuleFaint,
  folioArrowEdge: palette.folioPaperEdgeStrong,
  folioPressed: palette.folioPressed,
  folioPaper: palette.folioPaper,
  folioPaperEdge: palette.folioPaperEdge,
  selectionSurface: palette.selectionMist,
  selectionBorder: palette.selectionEdge,
  selectionBadge: palette.selectionBlush,
  incorrectBorder: palette.incorrectLine,
  feedbackIncorrect: palette.black,
  inkOnDark: palette.white,
  inkOnDarkMuted: palette.whiteMuted,
  inkOnDarkFaint: palette.whiteFaint,
  inkOnLight: palette.black,
  inkOnLightMuted: palette.blackMuted,
  inkOnLightFaint: palette.blackFaint,
  featureBackdrop: palette.ink,
  overlayButtonDark: palette.blackVeil,
  overlayButtonLight: palette.whiteVeil,
  inkHaloOnDark: palette.blackHalo,
  inkHaloOnLight: palette.whiteHalo,
  illustrationDawnLight: palette.dawnLight,
  illustrationDawn: palette.dawn,
  illustrationDawnDeep: palette.dawnDeep,
  illustrationRose: palette.rose,
  illustrationBlush: palette.blush,
  illustrationButter: palette.butter,
  illustrationLilac: palette.lilac,
  illustrationSky: palette.sky,
};

const darkColors: ColorTokens = {
  background: palette.slate900,
  launchPage: LAUNCH_PAGE,
  surface: palette.slate700,
  text: palette.white,
  textMuted: palette.grey,
  textInactive: palette.darkgrey,
  textSupporting: palette.silver,
  border: palette.ink600,
  borderStrong: palette.grey,
  divider: palette.mistOnDark,
  containerBorder: palette.cardEdgeOnDark,
  edgeOnSurface: palette.grabberOnDark,
  popoverDim: palette.dimOnDark,
  grabber: palette.grabberOnDark,
  progressTrack: palette.ink600,
  skeleton: palette.cardEdgeOnDark,
  accent: palette.accent,
  onAccent: palette.white,
  sequenceLine: palette.ink600,
  controlPrimary: palette.white,
  onControlPrimary: palette.black,
  onControlPrimaryMuted: palette.blackMuted,
  onControlPrimaryFaint: palette.blackFaint,
  success: palette.green,
  onSuccess: palette.black,
  onSuccessMuted: palette.blackMuted,
  onSuccessFaint: palette.blackFaint,
  onSuccessBright: palette.white,
  onSuccessBrightFaint: palette.whiteFaint,
  lightIcon: palette.lightIcon,
  selected: palette.green,
  toggleThumbOff: palette.greyLight,
  chromeIcon: palette.white,
  statusInk: palette.white,
  statusInkOnDark: palette.white,
  chromeTitle: palette.grey,
  chromeStepCounter: palette.grey,
  hairline: palette.hairlineOnDark,
  segmentBackground: palette.overlaySubtleOnDark,
  waitingFill: palette.cardEdgeOnDark,
  waitingInk: palette.grey,
  segmentActiveBackground: palette.overlayMediumOnDark,
  tabActiveBackground: palette.overlayStrongOnDark,
  stepLabelActive: palette.white,
  stepLabelInactive: palette.grey,
  // A dark bezel on a dark page still reads as a phone by its lit screen.
  deviceFrame: palette.pureBlack,
  shadow: palette.pureBlack,
  // A thumbnail is dark or light on its own terms; the scrim reads the same.
  mediaScrim: palette.scrim,
  onMediaScrim: palette.white,
  frostedRim: palette.frostOnDark,
  balloonSaved: palette.balloonGreen,
  balloonScrap: palette.balloonScrap,
  correct: palette.correctInk,
  correctSurface: palette.correctMistOnDark,
  correctBorder: palette.correctLineOnDark,
  incorrect: palette.amberOnDark,
  incorrectSurface: palette.incorrectMistOnDark,
  folioCloth: palette.folioCloth,
  folioClothEdge: palette.folioClothEdge,
  folioSpine: palette.pureBlack,
  folioInk: palette.folioPaper,
  folioInkMuted: palette.folioPaperMuted,
  folioInkFaint: palette.folioPaperFaint,
  folioRule: palette.folioPaperRule,
  folioRuleFaint: palette.folioPaperRuleFaint,
  folioArrowEdge: palette.folioPaperEdgeStrong,
  folioPressed: palette.folioPressed,
  folioPaper: palette.folioPaper,
  folioPaperEdge: palette.folioPaperEdge,
  selectionSurface: palette.selectionMistOnDark,
  selectionBorder: palette.selectionEdgeOnDark,
  selectionBadge: palette.selectionBlushOnDark,
  incorrectBorder: palette.incorrectLineOnDark,
  feedbackIncorrect: palette.white,
  inkOnDark: palette.white,
  inkOnDarkMuted: palette.whiteMuted,
  inkOnDarkFaint: palette.whiteFaint,
  inkOnLight: palette.black,
  inkOnLightMuted: palette.blackMuted,
  inkOnLightFaint: palette.blackFaint,
  featureBackdrop: palette.ink,
  overlayButtonDark: palette.blackVeil,
  overlayButtonLight: palette.whiteVeil,
  inkHaloOnDark: palette.blackHalo,
  inkHaloOnLight: palette.whiteHalo,
  // Matched to art whose light backdrop is baked in: they read the same.
  illustrationDawnLight: palette.dawnLight,
  illustrationDawn: palette.dawn,
  illustrationDawnDeep: palette.dawnDeep,
  illustrationRose: palette.rose,
  illustrationBlush: palette.blush,
  illustrationButter: palette.butter,
  illustrationLilac: palette.lilac,
  illustrationSky: palette.sky,
};

/**
 * The spacing scale: every gap, padding and margin the app repeats, in points,
 * each named by its own value so a mock's 22 reads as `space[22]`. A number not
 * on it is one-off geometry, kept beside its component as a named constant with
 * its reason (ADR 0016).
 *
 * Spacing, corners and control heights read the same in every theme, so they
 * are imported directly (`import { space } from "@/theme"`) and work inside
 * `StyleSheet.create`. Colour stays on `useTheme()`.
 */
export const space = {
  2: 2,
  4: 4,
  6: 6,
  8: 8,
  10: 10,
  12: 12,
  14: 14,
  15: 15,
  16: 16,
  18: 18,
  20: 20,
  22: 22,
  24: 24,
  28: 28,
  32: 32,
  36: 36,
  40: 40,
} as const;

/** The corner scale, named by value like `space`. `pill` rounds any height fully. */
export const radius = {
  10: 10,
  12: 12,
  14: 14,
  16: 16,
  20: 20,
  23: 23,
  24: 24,
  28: 28,
  32: 32,
  36: 36,
  pill: 999,
} as const;

/**
 * Motion, the same in every theme. `snap` and `sheet` are critically damped
 * and clamped: a thing that moves lands and stops — no bounce for the eye to
 * chase. `slide` keeps the least give, for an outline moving between choices.
 * Spread into Reanimated's `withSpring` with `reduceMotion` added.
 */
export const motion = {
  /** A marker landing on what's picked: a scale's dot, a filter's outline. */
  snap: { duration: 200, dampingRatio: 1, overshootClamping: true },
  /**
   * An outline sliding to what's picked — Plan Detail's day, the paper, the
   * tab, Plans' filter: one spring, quick with the least give, so every
   * selection in the app moves alike.
   */
  slide: { damping: 18, stiffness: 220, mass: 0.8 },
  /** A sheet rising from the bottom edge, as iOS's own do. */
  sheet: { duration: 380, dampingRatio: 1, overshootClamping: true },
  /** How long anything takes to leave: a sheet sliding down, a menu fading. */
  exitMs: 200,
  /**
   * A skeleton's breath, Apple's way: each half of the pulse this long, from
   * full to `skeletonDim` and back. Held still under Reduce Motion.
   */
  skeletonPulseMs: 900,
  skeletonDim: 0.5,
  /**
   * A page's parts arriving (the Daily Study): each fades in as it moves
   * `fromX` to the left into place — never up or down — `staggerMs` behind
   * the one before.
   */
  pageEnter: { durationMs: 420, staggerMs: 90, fromX: 16 },
  /** A skeleton handing over: it fades out as what it stood for fades in. */
  handoffMs: 280,
  /**
   * Options a switch turns on (Daily reminder's time and days): each part
   * fades in as it drifts `fromY` down into place, `staggerMs` behind the one
   * above. Turned off, they all fade out together, quicker (`exitMs`).
   */
  reveal: { durationMs: 320, staggerMs: 70, fromY: 8, exitMs: 140 },
  /**
   * A page's pieces arriving once the launch intro has gone (`Arrive`): the same
   * fade-and-drift as `reveal`, held `delayMs` so the intro is fully off the
   * screen first, travelling further and a little slower so the small header
   * reads as clearly as the hero, `staggerMs` behind the one before.
   */
  arrival: { delayMs: 120, durationMs: 400, staggerMs: 70, fromY: 16 },
  /**
   * Home's welcome, before a reader's first plan, played the first time only: a
   * blank beat (`blankMs`); the wordmark then the date fading in as they rise
   * `fromY` on a short spring with a hint of overshoot (`rise`, about 0.74 of
   * critical damping), `staggerMs` apart, faded over `fadeMs`; the kicker
   * fading in where it sits (`kickerMs`); the note typing in a letter every
   * `letterMs`, `paragraphPauseMs` between paragraphs, `typeDelayMs` after the
   * kicker; then, `buttonDelayMs` after the last letter, the empty pill
   * fading in as it rises over `cascadeMs`; `punchDelayMs` after it's settled,
   * its words punching in from `punchFrom` of their size as they rise `fromY`,
   * on a short, crisp spring (`punch`, about 0.56 of critical damping, settled
   * in about `punchSettleMs`) that springs back just past full; and
   * `offerDelayMs` after that, the link under it fading in gently over
   * `offerFadeMs`.
   */
  welcome: {
    blankMs: 300,
    rise: { damping: 20, stiffness: 260, mass: 0.7 },
    fromY: 8,
    fadeMs: 260,
    staggerMs: 70,
    kickerMs: 220,
    typeDelayMs: 150,
    letterMs: 18,
    paragraphPauseMs: 240,
    buttonDelayMs: 120,
    cascadeMs: 360,
    punchDelayMs: 200,
    punchFrom: 0.6,
    punch: { damping: 16, stiffness: 340, mass: 0.6 },
    punchSettleMs: 300,
    offerDelayMs: 150,
    offerFadeMs: 800,
  },
  /**
   * Progress's day panel arriving with a new day or passage: it fades in as it
   * rises `fromY` into place, easing out. Under Reduce Motion, the fade alone.
   */
  panelEnter: { durationMs: 480, fromY: 8 },
  /**
   * A row opening to show all of itself, and closing (The Word's passages):
   * a spring with a little give, so it settles softly. Everything below
   * moves with it.
   */
  expand: { damping: 18, stiffness: 180, mass: 1 },
  /**
   * A part of a page put away or brought back by a switch (The Word's chart):
   * it rolls up quickly, fading, and what's below moves up into its room.
   */
  rollUpMs: 220,
  /**
   * Search results as the words change: a row moves to its new place, a new
   * one fades in, one that no longer matches fades out (`exitMs`). Never
   * remounted. Under Reduce Motion, they settle without moving.
   */
  results: { moveMs: 240, enterMs: 200 },
} as const;

/**
 * The page's vertical edge fades — behind the status bar and a header, and
 * the dock's and tab bar's tint: how opaque they get at their solid end, so
 * what scrolls under them still shows, faintly. Each fade's whole ramp is
 * scaled by it, keeping its shape.
 */
export const edgeFade = { peak: 0.85 } as const;

/** The heights controls repeat. */
export const controlHeight = {
  /** The smallest a tap target gets: a compact button, an icon button, a header row. */
  hitTarget: 44,
  /** A one-line field or search bar (`FieldFrame`): its least height — large text grows it. */
  field: 52,
  /**
   * An inline pill — a chip, a value, a label that opens something: drawn this
   * tall, tapped at `hitTarget` (`pillHitSlop`). A standalone button is drawn at 44.
   */
  pill: 36,
  /** A tappable row in a list card: its least height. */
  row: 64,
  /** A header's round icon button. */
  headerButton: 49,
  /** A screen header's row. */
  header: 54,
  /** The full-width primary `Button`. */
  button: 61,
} as const;

/**
 * A card's corners and the room inside it, by what it holds. `list`: rows, each
 * bringing its own 16 in, so nothing inside the card itself. `content`: a block
 * to read or act on. `feature`: a page's one big card.
 */
export const cardStyle = {
  list: { radius: radius[24], inset: 0 },
  content: { radius: radius[28], inset: space[20] },
  feature: { radius: radius[32], inset: space[24] },
} as const;

export type CardRole = keyof typeof cardStyle;

/** The sizes a row's icons are drawn at: its quiet leading icon, the chevron it ends in, and a pill's small chevron. */
export const iconSize = { row: 20, chevron: 18, pillChevron: 14 } as const;

/** The margin round an inline pill that makes its tap 44pt, as Apple's guidelines ask. */
export const pillHitSlop = (controlHeight.hitTarget - controlHeight.pill) / 2;

/**
 * The older named scales, read through the theme (`theme.spacing.md`) by Fun
 * and Exams, which sit outside the token migration. Everything else uses
 * `space` and `radius`.
 */
const spacing = {
  xs: space[4],
  sm: space[8],
  md: space[16],
  lg: space[24],
  xl: space[32],
} as const;

/** `card` is a featured or tappable card's corner (Fun's hero, games, and banner). */
const radii = {
  sm: 6,
  md: radius[10],
  lg: radius[16],
  card: radius[20],
  xl: radius[24],
  pill: radius.pill,
} as const;

/**
 * `fontFamily` keys reference `src/theme/fonts.ts`'s custom-loaded cuts, and
 * every role names one, its `fontWeight` that cut's own: Canela for the
 * wordmark and the largest headlines, Canela Deck for titles and questions,
 * Tiempos Text for reading, Söhne for everything else (ADR 0034). Söhne is
 * set a touch tight from 20pt and a touch open at 13pt and under (±1% of its
 * size) where a role doesn't track itself.
 *
 * Sizes are fixed, not scaled at runtime. The design spec is drawn at a 320px
 * reference width; each value here is that spec multiplied by 1.228125 (the
 * 393pt baseline) and rounded once, so a 320px comp reads at its intended
 * presence without any width-derived scaling. Smaller and larger devices keep
 * these same absolute values and adapt through layout, not type size.
 */
const typography = {
  /** 16pt: the size the wordmark was set at in Libre Baskerville, kept through the change to Canela. */
  masthead: { fontFamily: fonts.masthead, fontSize: 16, fontWeight: "500" },
  editorialHeading: { fontFamily: fonts.editorialHeading, fontSize: 20, fontWeight: "500" },
  /** The editorial face, larger: the title of the day picked on Plan Detail. */
  editorialTitle: { fontFamily: fonts.editorialHeading, fontSize: 24, fontWeight: "500" },
  /**
   * A study question set in the editorial face (Reflect). Leaded at no less
   * than Canela Deck's own 1.3×: any tighter and iOS trims its tallest glyphs.
   */
  editorialQuestion: {
    fontFamily: fonts.editorialHeading,
    fontSize: 24,
    fontWeight: "500",
    lineHeight: 32,
  },
  /**
   * A question to be read through, a size under a study's (`editorialQuestion`):
   * RISE's questions in what was learned. Leaded at Canela Deck's own 1.3×,
   * so iOS never trims its tallest glyphs.
   */
  editorialQuestionCompact: {
    fontFamily: fonts.editorialHeading,
    fontSize: 20,
    fontWeight: "500",
    lineHeight: 26,
  },
  /** The editorial face at its largest: a page's own title (a theology exam's overview). */
  editorialDisplay: {
    fontFamily: fonts.display,
    fontSize: 34,
    fontWeight: "500",
    lineHeight: 43,
    letterSpacing: -0.3,
  },
  /**
   * The editorial face at its grandest: a page named like a book (Theology
   * Exams). The face's line is kept 1.25× its size: set any tighter, iOS
   * keeps the room below the baseline and trims the tops of its capitals
   * (0.75× its size) and ascenders.
   */
  editorialHero: {
    fontFamily: fonts.display,
    fontSize: 52,
    fontWeight: "500",
    lineHeight: 65,
    letterSpacing: -1.6,
  },
  /** A subject's name on its book's cover: set close, never so close it clips (1.25×). */
  folioTitle: {
    fontFamily: fonts.display,
    fontSize: 40,
    fontWeight: "500",
    lineHeight: 50,
    letterSpacing: -1.6,
  },
  /** …and on a book made shorter to fit a shorter screen. */
  folioTitleCompact: {
    fontFamily: fonts.display,
    fontSize: 30,
    fontWeight: "500",
    lineHeight: 38,
    letterSpacing: -1.2,
  },
  /** An exam's title in a book's list. */
  folioItem: { fontFamily: fonts.editorialBody, fontSize: 17, fontWeight: "400", lineHeight: 22 },
  /** A folio's small print — its kicker, its section — in the mono, capitals, tracked. */
  folioMeta: { fontFamily: fonts.metaLabel, fontSize: 11, fontWeight: "500", letterSpacing: 1.1 },
  /** A level above an exam in a folio — no smaller than iOS reads comfortably. */
  folioLevel: { fontFamily: fonts.metaLabel, fontSize: 11, fontWeight: "500", letterSpacing: 1 },
  /** The line under such a title: the editorial reading face, a size over body. */
  editorialLead: {
    fontFamily: fonts.editorialBody,
    fontSize: 19,
    fontWeight: "400",
    lineHeight: 26,
  },
  metaLabel: { fontFamily: fonts.metaLabel, fontSize: 13, fontWeight: "500" },
  /** `metaLabel`, tracked a point — a line of status set in capitals (a hero's, a day row's heading). */
  metaLabelTracked: {
    fontFamily: fonts.metaLabel,
    fontSize: 13,
    fontWeight: "500",
    letterSpacing: 1,
  },
  /** `metaLabelTracked` in the semibold cut: a tracked label that's also a control (Progress's week dates). */
  metaLabelTrackedStrong: {
    fontFamily: fonts.metaEmphasis,
    fontSize: 13,
    fontWeight: "600",
    letterSpacing: 1,
  },
  /**
   * A label set above what it names — a page's kicker ("Subject 01 / 12",
   * "Scripture & Reading / Foundations"), a section's name, an exam's level:
   * the mono, in capitals, tracked wide. One style, so every such label in
   * the app reads the same.
   */
  /**
   * The status bar's time, in the editorial face, a point under iOS's own: the serif sits larger.
   * Drawn at a fixed size (`StatusLabel`): the bar never grows with text.
   */
  statusBarTime: { fontFamily: fonts.editorialHeading, fontSize: 16, fontWeight: "500" },
  /** The status bar's time's colon: a step smaller, raised to the figures' middle. */
  statusBarColon: { fontFamily: fonts.editorialHeading, fontSize: 13, fontWeight: "500" },
  kicker: {
    fontFamily: fonts.metaLabel,
    fontSize: 13,
    fontWeight: "500",
    letterSpacing: 2,
    textTransform: "uppercase",
  },
  metaBody: { fontFamily: fonts.metaBody, fontSize: 13, fontWeight: "400" },
  metaEmphasis: { fontFamily: fonts.metaEmphasis, fontSize: 11, fontWeight: "600" },
  body: { fontFamily: fonts.ui, fontSize: 17, fontWeight: "400" },
  /** Body, leaded for a short paragraph in a sheet. */
  bodyLoose: { fontFamily: fonts.ui, fontSize: 17, fontWeight: "400", lineHeight: 26 },
  label: { fontFamily: fonts.uiMedium, fontSize: 14, fontWeight: "500" },
  headline: { fontFamily: fonts.uiBold, fontSize: 24, fontWeight: "700", letterSpacing: -0.24 },
  /** The headline's size at regular weight — a number chosen from a row (New Plan's days). */
  headlineRegular: { fontFamily: fonts.ui, fontSize: 24, fontWeight: "400", letterSpacing: -0.24 },
  /** A title on a large card (the Plans library's): bold, set close for up to three lines. */
  cardTitle: {
    fontFamily: fonts.uiBold,
    fontSize: 20,
    fontWeight: "700",
    lineHeight: 25,
    letterSpacing: -0.2,
  },
  smallCardTitle: { fontFamily: fonts.uiSemibold, fontSize: 18, fontWeight: "600", lineHeight: 22 },
  /** A plan's title on its card, over its artwork: Canela Deck, as plan titles are everywhere, at its own 1.3× leading. */
  offerTitle: {
    fontFamily: fonts.editorialHeading,
    fontSize: 20,
    fontWeight: "500",
    lineHeight: 26,
  },
  /** The number on a small tile (Plan Detail's days): large enough to read at a glance. */
  tileNumber: {
    fontFamily: fonts.uiSemibold,
    fontSize: 22,
    fontWeight: "600",
    letterSpacing: -0.22,
  },
  /** A study step's name on its row (Plan Detail's day): clear, and firm enough to tap. */
  stepTitle: { fontFamily: fonts.uiSemibold, fontSize: 18, fontWeight: "600", lineHeight: 24 },
  /** The date under it: small, in the hero's mono, set in capitals by the tile. */
  tileDate: { fontFamily: fonts.metaLabel, fontSize: 11, fontWeight: "500", letterSpacing: 0.6 },

  /**
   * The study featured on Home: Canela, large, at its own spacing — no
   * tracking pulled in — leaded over its own 1.22× so iOS never trims its tops.
   */
  featureTitle: { fontFamily: fonts.display, fontSize: 28, fontWeight: "500", lineHeight: 35 },
  /** Hero sentence: Canela, leaded just over its own 1.22× so iOS never trims its tops. */
  display: {
    fontFamily: fonts.display,
    fontSize: 37,
    fontWeight: "500",
    lineHeight: 46,
    letterSpacing: -1.11,
  },
  /**
   * The static weekday strip. Spec 17/-0.01em, IBM Plex Mono Medium — set a
   * touch under the spec's scaled 21, so the strip sits quieter under the
   * wordmark.
   */
  dayStrip: { fontFamily: fonts.metaLabel, fontSize: 19, fontWeight: "500", letterSpacing: -0.19 },
  /** The date opposite the wordmark on Home: a dateline in Söhne's regular weight, a size and a shade under ink, so the wordmark leads. */
  headerDate: {
    fontFamily: fonts.metaBody,
    fontSize: 14,
    fontWeight: "400",
    letterSpacing: -0.15,
  },
  /** Supporting copy and footnotes. Spec 11/1.45/0.02em, IBM Plex Mono. */
  supporting: {
    fontFamily: fonts.metaBody,
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 20,
    letterSpacing: 0.28,
  },
  /** Feature-row labels. Spec 13.5. */
  listItem: { fontFamily: fonts.uiMedium, fontSize: 17, fontWeight: "500" },
  /** A list item's weight, larger — a sermon's title over its preview. */
  listItemLarge: {
    fontFamily: fonts.uiMedium,
    fontSize: 20,
    fontWeight: "500",
    letterSpacing: -0.2,
  },
  /** A single letter standing for a day of the week, large enough to tap by: Daily reminder's days. */
  dayLetter: {
    fontFamily: fonts.uiSemibold,
    fontSize: 22,
    fontWeight: "600",
    letterSpacing: -0.22,
  },
  /** Button labels, both variants. Spec 15/-0.01em. */
  button: { fontFamily: fonts.uiSemibold, fontSize: 18, fontWeight: "600" },
  /** A compact button's label — a smaller call to action set on a colour. */
  compactButton: { fontFamily: fonts.uiSemibold, fontSize: 16, fontWeight: "600" },
  /** A heading over one section of a scrolling page ("Play now"): bold, a step under `headline`. */
  sectionTitle: {
    fontFamily: fonts.uiBold,
    fontSize: 22,
    fontWeight: "700",
    lineHeight: 28,
    letterSpacing: -0.22,
  },
  /** A title on a tile or a small card (Fun's games): bold, set close. */
  tileTitle: { fontFamily: fonts.uiBold, fontSize: 17, fontWeight: "700", lineHeight: 22 },
  /** Supporting copy on a card, under its title: a line or two, quiet. */
  cardDetail: { fontFamily: fonts.ui, fontSize: 15, fontWeight: "400", lineHeight: 20 },
  /** A row's description under its name (Settings' options, About's rows): leaded, so two or three lines still read easily. */
  rowDetail: { fontFamily: fonts.ui, fontSize: 15, fontWeight: "400", lineHeight: 22 },
  /** A search result's title: regular, leaded for two lines read at a glance (Plans' search). */
  resultTitle: { fontFamily: fonts.ui, fontSize: 17, fontWeight: "400", lineHeight: 23 },
  /** The words a search found, inside a regular line: medium, the rest left regular. */
  match: { fontFamily: fonts.uiMedium, fontWeight: "500" },
  /** A line of facts under a page's title ("12 subjects · 48 exams"): the system face, firm and easy to read. */
  summaryStrong: { fontFamily: fonts.uiSemibold, fontSize: 15, fontWeight: "600", lineHeight: 20 },
  /** A fact set plainly in a row ("15 questions", "8–12 min"): the system face, small and firm enough to read. */
  factLabel: {
    fontFamily: fonts.uiSemibold,
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0.13,
  },
  /** A tag's label — a small pill naming a kind or a count ("Quiz", "12 day streak"). */
  tag: {
    fontFamily: fonts.uiSemibold,
    fontSize: 12,
    fontWeight: "600",
    lineHeight: 16,
    letterSpacing: 0.12,
  },

  /** Centered header title ("New plan", "Day 2 of 6", "Quick check"). Spec 14/500. */
  navTitle: { fontFamily: fonts.uiMedium, fontSize: 17, fontWeight: "500" },
  /** A full-screen fallback's heading ("Something went wrong") — where the app's own components can't be used. */
  fallbackTitle: {
    fontFamily: fonts.uiSemibold,
    fontSize: 20,
    fontWeight: "600",
    letterSpacing: -0.2,
  },
  /** …its message… */
  fallbackBody: { fontFamily: fonts.ui, fontSize: 15, fontWeight: "400" },
  /** …and its one action ("Try again"). */
  fallbackAction: { fontFamily: fonts.uiSemibold, fontSize: 15, fontWeight: "600" },
  /** The clock in a drawn phone's status bar (the Welcome tour's phones). */
  statusTime: { fontFamily: fonts.uiSemibold, fontSize: 17, fontWeight: "600" },
  /** A message's title on an emptied page (Plans' search): medium, a step under a page's own title. */
  messageTitle: {
    fontFamily: fonts.uiMedium,
    fontSize: 24,
    fontWeight: "500",
    lineHeight: 30,
    letterSpacing: -0.24,
  },
  /** Top-level tab-root titles (Plans, Progress, Settings). Spec 24/500/1.12/-0.02em. */
  screenTitle: {
    fontFamily: fonts.uiMedium,
    fontSize: 29,
    fontWeight: "500",
    lineHeight: 32,
    letterSpacing: -0.58,
  },
  /** A header's right-aligned step count ("1 of 2"). Spec 11 mono/0.02em. */
  stepCounter: { fontFamily: fonts.metaBody, fontSize: 14, fontWeight: "400", letterSpacing: 0.28 },
  /** A segmented control's option label. Spec 12.5/400. */
  segmentLabel: { fontFamily: fonts.ui, fontSize: 15, fontWeight: "400" },
  /** The picked option's label: the same size, firmer. */
  segmentLabelActive: { fontFamily: fonts.uiSemibold, fontSize: 15, fontWeight: "600" },
  /** A borderless filter-tabs label (Plans' All/In progress/Done/Saved row). Spec 13/400. */
  filterLabel: { fontFamily: fonts.ui, fontSize: 16, fontWeight: "400" },
  /** A filter tab's superscript count. Spec 9pt. */
  filterCount: { fontFamily: fonts.ui, fontSize: 11, fontWeight: "400", letterSpacing: 0.11 },
  /** A Daily Study step label (Read/Scripture/Reflect/Pray) below the progress line. */
  stepLabel: {
    fontFamily: fonts.ui,
    fontSize: 13,
    fontWeight: "400",
    lineHeight: 16,
    letterSpacing: 0.13,
  },
  /** Long-form reading (a Daily Study's Read step): Tiempos Text at body size, leaded about 1.6× for a page of it. */
  reading: { fontFamily: fonts.editorialBody, fontSize: 17, fontWeight: "400", lineHeight: 27 },
  /** A Scripture passage set as the page's centrepiece. The editorial face, generously leaded. */
  scripture: { fontFamily: fonts.editorialBody, fontSize: 24, fontWeight: "400", lineHeight: 36 },
  /**
   * A section's opening paragraph, set apart as a magazine's standfirst: the
   * editorial face, a step below `scripture` (About this plan's overview).
   */
  standfirst: { fontFamily: fonts.editorialBody, fontSize: 20, fontWeight: "400", lineHeight: 30 },
  /** One line from a passage, standing for it in a list (The Word): the Scripture face, small. */
  scriptureLine: {
    fontFamily: fonts.editorialBody,
    fontSize: 17,
    fontWeight: "400",
    lineHeight: 24,
  },
  /**
   * A question set as the page's centrepiece (a theology exam's): the
   * editorial face, a step over `editorialTitle`, leaded for several lines.
   */
  question: { fontFamily: fonts.editorialHeading, fontSize: 26, fontWeight: "500", lineHeight: 34 },
  /**
   * A Quick Check question: the editorial face, as Scripture study is set, a
   * touch under a screen title, leaded so a long question reads easily.
   */
  quizQuestion: {
    fontFamily: fonts.editorialHeading,
    fontSize: 24,
    fontWeight: "500",
    lineHeight: 33,
  },
  /** A line to keep, set apart on a reading page: the editorial face, leaded. */
  pullLine: { fontFamily: fonts.editorialHeading, fontSize: 20, fontWeight: "500", lineHeight: 28 },
} as const;

/**
 * Shadow geometry for raised surfaces. Colour comes from `colors.shadow`, so
 * a component composes `{ shadowColor: theme.colors.shadow, ...theme.elevation.card }`.
 */
const elevation = {
  /** A floating card, e.g. the Welcome screen's fanned phone mocks. */
  card: { shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.18, shadowRadius: 16 },
  /** A book lying on the page: an exam subject's folio. */
  folio: { shadowOffset: { width: 0, height: 18 }, shadowOpacity: 0.14, shadowRadius: 16 },
  /** A menu floating over the page: a soft, wide shadow. */
  menu: { shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.12, shadowRadius: 24 },
  /** An answer to tap, lifted just off the page: a Quick Check choice. */
  choice: { shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8 },
  /** A control floating over what's behind it — the search bar on the keyboard: soft, close. */
  floating: { shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 12 },
  /** A toggle's knob, sitting just proud of its track. */
  thumb: { shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.16, shadowRadius: 4 },
} as const;

/**
 * Line icons (lucide) share one stroke weight across the chrome — header
 * buttons and tab bar alike — so they read as one family.
 */
const icon = {
  strokeWidth: 2,
  /** A row's chevron that should read clearly at a glance (Progress's rows, The Word's): firmer. */
  strokeWidthStrong: 2.5,
} as const;

export const lightTheme = {
  name: "light",
  colors: lightColors,
  palette,
  spacing,
  radii,
  typography,
  icon,
  elevation,
} as const;

/**
 * Read only on a dark reading paper (`getReadingTheme`) for now — app-wide
 * dark mode is a deliberate future feature with its own design, not a
 * response to the OS colour scheme (see `use-theme.ts`).
 */
export const darkTheme = {
  name: "dark",
  colors: darkColors,
  palette,
  spacing,
  radii,
  typography,
  icon,
  elevation,
} as const;

export type Theme = typeof lightTheme | typeof darkTheme;

/**
 * The papers the Daily Study can be read on, in the reading sheet's order: a
 * light paper keeps the light theme's ink, a dark one takes the dark theme's
 * (`getReadingTheme`). Fixed colours, the same whatever the app's theme.
 */
export const READING_PAPERS: readonly {
  id: ReadingPaper;
  label: string;
  background: string;
  dark: boolean;
}[] = [
  { id: "white", label: "White", background: palette.white, dark: false },
  { id: "ivory", label: "Ivory", background: palette.paperIvory, dark: false },
  { id: "cream", label: "Cream", background: palette.paperCream, dark: false },
  { id: "sepia", label: "Sepia", background: palette.paperSepia, dark: false },
  { id: "dusk", label: "Dusk", background: palette.paperDusk, dark: true },
  { id: "night", label: "Night", background: palette.slate900, dark: true },
];
